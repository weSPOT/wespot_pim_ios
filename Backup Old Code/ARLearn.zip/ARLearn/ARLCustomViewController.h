//
//  ARLCustomViewController.h
//  ARLearn
//
//  Created by Stefaan Ternier on 7/10/13.
//  Copyright (c) 2013 Stefaan Ternier. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ARLPageViewController.h"
@interface ARLCustomViewController : ARLPageViewController

@end
