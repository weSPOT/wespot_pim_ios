//
//  ARLFileTableViewController.h
//  ARLearn
//
//  Created by Stefaan Ternier on 4/9/13.
//  Copyright (c) 2013 Stefaan Ternier. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DownloadHelperDelegate.h"

@interface ARLFileTableViewController : UITableViewController <DownloadHelperDelegate>

@end
