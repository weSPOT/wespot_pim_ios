//
//  ARLGeneralItemViewCell.h
//  ARLearn
//
//  Created by Stefaan Ternier on 1/14/13.
//  Copyright (c) 2013 Stefaan Ternier. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ARLGeneralItemViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *itemTitle;

@end
