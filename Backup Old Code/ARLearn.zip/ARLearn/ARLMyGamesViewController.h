//
//  ARLMyGamesViewController.h
//  ARLearn
//
//  Created by Stefaan Ternier on 8/13/13.
//  Copyright (c) 2013 Stefaan Ternier. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreDataTableViewController.h"
#import "Game+ARLearnBeanCreate.h"
#import "ARLAppDelegate.h"

@interface ARLMyGamesViewController : CoreDataTableViewController

@end
