//
//  ARLPortaitViewController.h
//  ARLearn
//
//  Created by Stefaan Ternier on 8/14/13.
//  Copyright (c) 2013 Stefaan Ternier. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ARLPortaitViewController : UINavigationController




@end
