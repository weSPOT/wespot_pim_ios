//
//  ARLToggleButton.m
//  ARLearn
//
//  Created by Stefaan Ternier on 7/15/13.
//  Copyright (c) 2013 Stefaan Ternier. All rights reserved.
//

#import "ARLToggleButton.h"

@implementation ARLToggleButton

@synthesize selected = _selected;

- (id)initWithFrame {
    self = [super init];
    if (self) {
        self.selected = NO;

        
    }
    return self;
}




@end
