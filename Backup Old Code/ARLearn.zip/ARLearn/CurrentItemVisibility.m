//
//  CurrentItemVisibility.m
//  ARLearn
//
//  Created by Stefaan Ternier on 8/6/13.
//  Copyright (c) 2013 Stefaan Ternier. All rights reserved.
//

#import "CurrentItemVisibility.h"
#import "GeneralItem.h"
#import "Run.h"


@implementation CurrentItemVisibility

@dynamic visible;
@dynamic item;
@dynamic run;

@end
